# String Calculator Kata

From Roy Osherove

[String Calculator 1](https://osherove.com/tdd-kata-1)
