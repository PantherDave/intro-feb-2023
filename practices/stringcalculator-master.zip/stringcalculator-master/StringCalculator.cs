﻿
namespace StringCalculator;

public class StringCalculator
{

    public int Add(string numbers)
    {
        return -42;
    }
}
